import React, { useState, useEffect } from 'react';
import { Star, ChevronLeft, ChevronRight, TrendingUp, Clock, Heart, DollarSign, Package } from 'lucide-react';

const testimonials = [
  {
    name: "Sarah Mitchell",
    company: "RE/MAX",
    metric: "Increased listings by 40%",
    quote: "3DtoVideo transformed how I market properties. The 24-hour delivery is incredible, and my clients love the professional video packages.",
    rating: 5
  },
  {
    name: "David Chen",
    company: "Coldwell Banker",
    metric: "Saves 10 hours per property",
    quote: "What used to take me weeks now happens overnight. The consistency and quality have helped me scale my video offerings significantly.",
    rating: 5
  },
  {
    name: "Maria Rodriguez",
    company: "Century 21",
    metric: "Doubled client engagement",
    quote: "The video quality is outstanding and the turnaround time is unmatched. This service has become essential to my marketing strategy.",
    rating: 5
  }
];

const metrics = [
  { icon: Package, value: "Starting", label: "New Service" },
  { icon: Clock, value: "24h*", label: "Mon-Thu Delivery" },
  { icon: Heart, value: "Quality", label: "Guaranteed" },
  { icon: DollarSign, value: "Zero", label: "Setup Fees" }
];

const SocialProof: React.FC = () => {

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">

        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Professional Video Conversion Service
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Transform your Matterport tours and photos into professional marketing videos
          </p>
        </div>

        {/* Service Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {metrics.map((metric, index) => (
            <div key={index} className="text-center">
              <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow">
                <metric.icon className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <div className="text-3xl font-bold text-gray-900 mb-1">{metric.value}</div>
                <div className="text-gray-600 text-sm">{metric.label}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProof;