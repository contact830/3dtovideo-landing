import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const faqData = [
  {
    question: "Is there any commitment or contract required?",
    answer: "NO. Month-to-month, cancel anytime, no questions asked."
  },
  {
    question: "How does the subscription work?",
    answer: "Simple. Each plan includes a fixed number of properties per month. Any size property counts as one property slot."
  },
  {
    question: "Will clients know I didn't create the videos and website?",
    answer: "NO. Features YOUR photos + YOUR branding throughout. Whether you're new to video or already doing custom work, clients see professional results with your brand."
  },
  {
    question: "How fast will I see results?",
    answer: "30 days. Non-video photographers start offering complete marketing packages immediately. Video pros can finally say YES to standard listing requests and see revenue growth within first month."
  },
  {
    question: "Can I still do custom video work?",
    answer: "YES. Perfect for video pros - use us for standard properties ($450-600 range) and save your time/energy for luxury custom work ($1,000+ range) where premium pricing is accepted."
  },
  {
    question: "What if I don't use all my properties?",
    answer: "EXPIRE. Unused properties expire monthly, no rollover to next month."
  },
  {
    question: "What's included in the property website?",
    answer: "Complete showcase. Mobile-optimized site with advanced photo player, Matterport tour link, Walkthrough Video (Branded), and agent contact information. Custom branding and 30-day hosting included."
  }
];

const FAQ: React.FC = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);

  const toggleItem = (index: number) => {
    setOpenItems(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  return (
    <section id="faq" className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            FAQ
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Get answers to the most common questions about our service
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="space-y-4">
            {faqData.map((faq, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden"
              >
                <button
                  onClick={() => toggleItem(index)}
                  className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
                >
                  <span className="font-semibold text-gray-900 pr-4">
                    Q: {faq.question}
                  </span>
                  {openItems.includes(index) ? (
                    <ChevronUp className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                
                {openItems.includes(index) && (
                  <div className="px-6 pb-4">
                    <div className="pt-2 border-t border-gray-100">
                      <p className="text-gray-700 leading-relaxed">
                        <span className="font-semibold text-blue-600">A:</span> {faq.answer}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;