import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ProblemSolution from './components/ProblemSolution';
import ProductShowcase from './components/ProductShowcase';
import Process from './components/Process';
import Portfolio from './components/Portfolio';
import FAQ from './components/FAQ';
import SocialProof from './components/SocialProof';
import Footer from './components/Footer';
import ROICalculatorPricing from './components/ROICalculatorPricing';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <Header />
      <Hero />
      <ProblemSolution />
      <Process />
      <ROICalculatorPricing />
      <ProductShowcase />
      <FAQ />
      <Footer />
    </div>
  );
};

export default App;