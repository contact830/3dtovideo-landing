import React, { useState } from 'react';
import { Play, Eye, Image, Plane, Sparkles, Globe } from 'lucide-react';

// Full HD SVG Logo Component
const FullHDLogo: React.FC = () => (
  <svg width="48" height="20" viewBox="0 0 48 20" fill="none" xmlns="http://www.w3.org/2000/svg" className="inline-block">
    <rect width="48" height="20" rx="4" fill="#3C59B2" />
    <text x="24" y="14" textAnchor="middle" fill="white" fontSize="8" fontWeight="bold" fontFamily="Arial, sans-serif">
      FULL HD
    </text>
  </svg>
);

const products = [
  {
    id: 'walkthrough',
    title: 'Walkthrough Video (Branded)', 
    icon: Play,
    quality: <FullHDLogo />,
    features: ['Complete property flow', 'Professional branding'],
    useCases: ['Social media marketing', 'Agent website showcase', 'Email campaigns'],
    preview: 'Play'
  },
  {
    id: 'walkthrough-unbranded',
    title: 'Walkthrough Video (Non Branded)',
    icon: Play,
    quality: <FullHDLogo />,
    features: ['Complete property flow', 'No branding'],
    useCases: ['Social media marketing', 'Agent website showcase', 'Client presentations'],
    preview: 'Clean walkthrough without branding'
  },
  {
    id: '360',
    title: '360° Showcase + Template',
    icon: Eye,
    quality: (
      <div className="flex items-center space-x-2">
        <FullHDLogo />
        <span>• Immersive room-by-room experience</span>
      </div>
    ),
    features: ['Multiple templates', 'Quick previews'],
    useCases: ['Social media stories', 'Email campaigns', 'Website integration'],
    preview: '360° interactive experience'
  },
  {
    id: 'slideshow',
    title: 'Premium Marketing Slideshow',
    icon: Image,
    quality: (
      <div className="flex items-center space-x-2">
        <FullHDLogo />
        <span>• 30 photos max</span>
      </div>
    ),
    features: ['4 Premium transitions', 'Professional layouts', 'Custom timing'],
    useCases: ['Email marketing', 'Presentations', 'Print materials'],
    preview: 'Professional slideshow presentation'
  },
  {
    id: 'slideshow-short',
    title: 'Premium Marketing Slideshow (Short)',
    icon: Image,
    quality: (
      <div className="flex items-center space-x-2">
        <FullHDLogo />
        <span>• 7 photos max</span>
      </div>
    ),
    features: ['Quick showcase format', 'Premium transitions', 'Social media optimized'],
    useCases: ['Social media posts', 'Instagram stories', 'Quick previews'],
    preview: 'Short-form slideshow for social media'
  },
  {
    id: 'website',
    title: 'All-in-One Website',
    icon: Globe,
    quality: 'BONUS',
    features: ['Mobile-responsive design', 'SEO optimized', 'Property showcase'],
    useCases: ['Lead generation', 'Professional presentation', 'Client sharing'],
    preview: 'Complete property website'
  }
];

const ProductShowcase: React.FC = () => {
  const [activeTab, setActiveTab] = useState('walkthrough');
  const activeProduct = products.find(p => p.id === activeTab);

  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            What You Get: 5 Professional Videos From Your Assets
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Send us your Matterport tour and photos - we'll convert them into these 5 professional marketing videos
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Tabs */}
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {products.map((product) => (
              <button
                key={product.id}
                onClick={() => setActiveTab(product.id)}
                className={`flex items-center space-x-2 px-4 py-3 rounded-xl font-medium transition-all duration-200 ${
                  product.id === 'website'
                    ? activeTab === product.id
                      ? 'bg-green-600 text-white shadow-lg'
                      : 'bg-green-100 text-green-700 hover:bg-green-200 border border-green-300'
                    : activeTab === product.id
                      ? 'bg-blue-600 text-white shadow-lg'
                      : 'bg-white text-gray-600 hover:bg-gray-50 border border-gray-200'
                }`}
              >
                <product.icon className="w-4 h-4" />
                <span className="hidden sm:inline">{product.title}</span>
                <span className="sm:hidden">{product.title.split(' ')[0]}</span>
                {product.id === 'website' && (
                  <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                    BONUS
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Content */}
          {activeProduct && (
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
              <div className="grid lg:grid-cols-2 gap-0 min-h-[400px]">
                {/* Preview */}
                <div className="bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center relative">
                  {activeProduct.id === 'website' ? (
                    <div className="text-center text-white p-8">
                      <Globe className="w-16 h-16 mx-auto mb-4 text-green-400" />
                      <h3 className="text-xl font-bold mb-2">Property Website Demo</h3>
                      <p className="text-gray-300 mb-4">Complete mobile-responsive website for your property</p>
                      <button className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg font-medium transition-colors">
                        View Demo Site
                      </button>
                    </div>
                  ) : activeProduct.id === 'walkthrough' ? (
                    <iframe
                      className="w-full h-full absolute inset-0"
                      src="https://www.youtube.com/embed/Ar2fLyRiWvY?start=1"
                      title="Walkthrough Video (Branded) Preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    ></iframe>
                  ) : activeProduct.id === 'walkthrough-unbranded' ? (
                    <iframe
                      className="w-full h-full absolute inset-0"
                      src="https://www.youtube.com/embed/Wx8lio3JFc4"
                      title="Walkthrough Video (Non Branded) Preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    ></iframe>
                  ) : activeProduct.id === '360' ? (
                    <iframe
                      className="w-full h-full absolute inset-0"
                      src="https://www.youtube.com/embed/fHMWQkpJZtM"
                      title="360° Showcase + Template Preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    ></iframe>
                  ) : activeProduct.id === 'slideshow' ? (
                    <iframe
                      className="w-full h-full absolute inset-0"
                      src="https://www.youtube.com/embed/xv59KUtu8xM"
                      title="Premium Marketing Slideshow Preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    ></iframe>
                  ) : (
                    <iframe
                      className="w-full h-full absolute inset-0"
                      src="https://www.youtube.com/embed/h4HZSATvnjc"
                      title="Premium Marketing Slideshow (Short) Preview"
                      frameBorder="0"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                      allowFullScreen
                    ></iframe>
                  )}
                </div>

                {/* Details */}
                <div className={`p-8 lg:p-12 flex flex-col justify-center ${activeProduct.id === 'website' ? 'bg-gradient-to-br from-green-50 to-green-100' : ''}`}>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{activeProduct.title}</h3>
                  {activeProduct.subtitle && (
                    <p className="text-lg font-medium text-gray-700 mb-2">{activeProduct.subtitle}</p>
                  )}
                  <div className={`mb-6 ${activeProduct.id === 'website' ? 'text-green-700 font-semibold' : 'text-gray-600'}`}>
                    {typeof activeProduct.quality === 'string' ? activeProduct.quality : activeProduct.quality}
                    {activeProduct.duration && ` • ${activeProduct.duration}`}
                  </div>

                  <div className="space-y-6">
                      <ul className="space-y-2 mb-6">
                        {(activeProduct.features || []).map((feature, index) => (
                          <li key={index} className="flex items-center space-x-2">
                            <div className={`w-2 h-2 rounded-full ${activeProduct.id === 'website' ? 'bg-green-600' : 'bg-blue-600'}`}></div>
                            <span className="text-gray-700">{feature}</span>
                          </li>
                        ))}
                      </ul>

                      <div className="flex flex-wrap gap-2">
                        {activeProduct.useCases.map((useCase, index) => (
                          <span
                            key={index}
                            className={`px-3 py-1 rounded-full text-sm ${
                              activeProduct.id === 'website' 
                                ? 'bg-green-100 text-green-800' 
                                : 'bg-blue-100 text-blue-800'
                            }`}
                          >
                            {useCase}
                          </span>
                        ))}
                      </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default ProductShowcase;