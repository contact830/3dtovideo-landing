import React from 'react';
import { Play, Clock, Package, Zap, Plane } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-24 pb-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8 text-center">
            <div className="space-y-4">
              <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 leading-tight whitespace-nowrap">
                Start Selling{' '}
                <span style={{ color: '#3C59B2' }}>
                  Video Today
                </span>
              </h1>
              <p className="text-lg sm:text-xl md:text-2xl text-gray-600 leading-relaxed">
                Send photos + Matterport → Get complete package
              </p>
            </div>

            {/* Value Proposition Box */}
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 shadow-lg">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center flex flex-col items-center justify-center">
                  <div 
                    className="text-2xl font-bold"
                    style={{ color: '#3C59B2' }}
                  >
                    $160/per property
                  </div>
                  <div className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded-full mt-1">
                    Volume discounts available
                  </div>
                </div>
                <div className="text-center border-l border-r border-gray-200 flex flex-col items-center justify-center">
                  <div className="text-2xl font-bold text-green-600">24h*</div>
                  <div className="text-sm text-gray-600">Mon-Thu delivery</div>
                </div>
                <div className="text-center flex flex-col items-center justify-center">
                  <div className="text-2xl font-bold text-orange-600">Complete</div>
                  <div className="text-sm text-gray-600">marketing package</div>
                </div>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col gap-4 mt-12 justify-center">
              <a 
                href="#pricing"
                className="text-white px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-xl"
                style={{ backgroundColor: '#3C59B2' }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#2A4A8F';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#3C59B2';
                }}
              >
                Get Started Now
              </a>
              <button 
                className="border-2 px-8 py-4 rounded-xl font-semibold text-lg transition-all duration-200 flex items-center justify-center space-x-2 hover:bg-blue-50 transform hover:scale-105"
                style={{ 
                  borderColor: '#3C59B2', 
                  color: '#3C59B2' 
                }}
              >
                <span>Videos with Drone Clips Available Soon</span>
              </button>
            </div>

          </div>

          {/* Right Column - Hero Video */}
          <div className="lg:pl-8">
            <div className="relative">
              <div 
                className="rounded-2xl p-1"
                style={{
                  background: `linear-gradient(to right, #3C59B2, #16a34a)`
                }}
              >
                <div className="bg-gray-900 rounded-xl overflow-hidden relative">
                  <iframe
                    className="w-full aspect-video"
                    src="https://www.youtube.com/embed/syeVR2aA4mU"
                    title="Industry Expert Interview - Adding Video Services to Photo Packages"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                    loading="lazy"
                  ></iframe>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;