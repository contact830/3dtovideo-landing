import React from 'react';
import { Play, Calendar, Download, Shield, Clock, CreditCard, RotateCcw } from 'lucide-react';

const FinalCTA: React.FC = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-blue-600 via-blue-700 to-green-600">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center text-white mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Convert Your Assets Into Professional Videos?
          </h2>
          <p className="text-xl opacity-90 max-w-3xl mx-auto">
            Join hundreds of real estate professionals who convert their Matterport tours and photos into 5 professional marketing videos with 3DtoVideo
          </p>
        </div>

        {/* Triple CTA Strategy */}
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
          {/* Primary CTA */}
          <div className="bg-white rounded-2xl p-8 text-center shadow-xl hover:shadow-2xl transition-shadow">
            <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Play className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Get Started</h3>
            <p className="text-gray-600 mb-6">Start transforming properties</p>
            <button className="bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-xl font-semibold text-lg w-full transition-all duration-200 transform hover:scale-105">
              Subscribe Now
            </button>
          </div>

          {/* Secondary CTA */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center border border-white/20">
            <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Calendar className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Schedule Demo</h3>
            <p className="text-white/80 mb-6">See it in action</p>
            <button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border border-white/30 px-8 py-4 rounded-xl font-semibold text-lg w-full transition-all duration-200">
              Book a Demo Call
            </button>
          </div>

          {/* Tertiary CTA */}
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center border border-white/20">
            <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <Download className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Sample Package</h3>
            <p className="text-white/80 mb-6">Download examples</p>
            <button className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border border-white/30 px-8 py-4 rounded-xl font-semibold text-lg w-full transition-all duration-200">
              Download Samples
            </button>
          </div>
        </div>

        {/* Risk Reversal */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 max-w-4xl mx-auto border border-white/20">
          <h3 className="text-xl font-bold text-white text-center mb-8">100% Risk-Free Guarantee</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center text-white">
              <Shield className="w-8 h-8 mx-auto mb-2 opacity-80" />
              <div className="font-semibold">30-day guarantee</div>
            </div>
            <div className="text-center text-white">
              <CreditCard className="w-8 h-8 mx-auto mb-2 opacity-80" />
              <div className="font-semibold">No setup fees</div>
            </div>
            <div className="text-center text-white">
              <RotateCcw className="w-8 h-8 mx-auto mb-2 opacity-80" />
              <div className="font-semibold">Cancel anytime</div>
            </div>
            <div className="text-center text-white">
              <Clock className="w-8 h-8 mx-auto mb-2 opacity-80" />
              <div className="font-semibold">Money-back guarantee</div>
            </div>
          </div>
        </div>

        {/* Final Urgency */}
        <div className="text-center mt-12">
          <p className="text-white/90 text-lg mb-4">
            Ready to 10x your video revenue? Your competitors are already ahead.
          </p>
          <p className="text-white/70">
            Start your transformation today - it takes less than 2 minutes to get started.
          </p>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;