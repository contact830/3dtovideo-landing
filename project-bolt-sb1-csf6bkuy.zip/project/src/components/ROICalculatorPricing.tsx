import React, { useState } from 'react';
import { Check, Calculator, DollarSign, ArrowRight } from 'lucide-react';

const ROICalculatorPricing: React.FC = () => {
  // State for each plan's pricing
  const [prices, setPrices] = useState({
    starter: '350',
    professional: '350',
    enterprise: '350'
  });

  const updatePrice = (planId: string, newPrice: string) => {
    setPrices(prev => ({
      ...prev,
      [planId]: newPrice
    }));
  };

  const plans = [
    {
      id: 'starter',
      name: 'Starter',
      capacity: '5 properties/month',
      description: 'Perfect for testing the waters',
      monthlyPrice: 800,
      costPerProperty: 160,
      properties: 5
    },
    {
      id: 'professional',
      name: 'Professional',
      capacity: '10 properties/month', 
      description: 'Most popular choice',
      monthlyPrice: 1520,
      costPerProperty: 152,
      properties: 10,
      recommended: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      capacity: '20 properties/month',
      description: 'Scale your revenue', 
      monthlyPrice: 2880,
      costPerProperty: 144,
      properties: 20
    }
  ];

  return (
    <section className="py-20" id="pricing">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Calculate Your Profit
          </h2>
          <p className="text-xl text-gray-600">
            See exactly how much money you'll make with each plan
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan) => {
            const currentPrice = prices[plan.id as keyof typeof prices];
            const profit = Math.max(0, currentPrice - plan.costPerProperty);
            const monthlyProfit = profit * plan.properties;

            return (
              <div 
                key={plan.id}
                className={`bg-white rounded-2xl p-6 shadow-lg ${
                  plan.recommended 
                    ? 'border-2 border-[#3C59B2] transform scale-105' 
                    : 'border border-gray-200'
                } transform hover:scale-110 transition-transform duration-200`}
              >
                {/* Recommended Badge */}
                {plan.recommended && (
                  <div className="text-center mb-4">
                    <span className="bg-[#3C59B2] text-white px-4 py-1 rounded-full text-sm font-medium">
                      Most Popular
                    </span>
                  </div>
                )}

                {/* Plan Header */}
                <div className="text-center mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-[#3C59B2] font-semibold">{plan.capacity}</p>
                  <p className="text-gray-600 text-sm">{plan.description}</p>
                </div>

                {/* Price Display */}
                <div className="text-center mb-6 pb-4 border-b">
                  <div className="text-4xl font-bold text-[#3C59B2] mb-1">
                    ${plan.monthlyPrice.toLocaleString()}
                    <span className="text-lg text-gray-600">/month</span>
                  </div>
                  <p className="text-gray-600 mb-2">${plan.costPerProperty} per property</p>
                  {plan.id === 'professional' && (
                    <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      Save 5%
                    </span>
                  )}
                  {plan.id === 'enterprise' && (
                    <span className="bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                      Save 10%
                    </span>
                  )}
                </div>

                {/* Calculator */}
                <div className="bg-blue-50 rounded-xl p-4 mb-6">
                  <div className="mb-4">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      You charge per property:
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-3 text-[#3C59B2] font-bold">$</span>
                      <input
                        type="number"
                        value={currentPrice}
                        onChange={(e) => updatePrice(plan.id, e.target.value)}
                        className={`w-full pl-8 pr-4 py-3 border rounded-lg text-center font-bold focus:border-[#3C59B2] focus:outline-none ${
                          currentPrice === '' ? 'text-gray-400 bg-gray-50' : 'text-gray-900 bg-white'
                        }`}
                        min="0"
                        placeholder="350"
                      />
                    </div>
                  </div>

                  <div className="space-y-2 pt-4 border-t">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Our cost:</span>
                      <span className="font-bold">${plan.costPerProperty}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Your profit:</span>
                      <span className="font-bold text-green-600">
                        ${currentPrice === '' ? '0' : profit}
                      </span>
                    </div>
                    <div className="flex justify-between pt-2 border-t">
                      <span className="text-gray-700">Monthly profit:</span>
                      <div className="text-right">
                        <div className="font-bold text-[#3C59B2] text-xl">
                          ${currentPrice === '' ? '0' : monthlyProfit.toLocaleString()}
                        </div>
                        <div className="text-xs text-gray-500">
                          ({plan.properties} × ${currentPrice === '' ? '0' : profit})
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-6">
                  <div className="space-y-2">
                    {['5 videos + 1 website per property', '24-hour delivery guarantee', 'Cancel anytime, no contracts'].map((feature, index) => (
                      <div key={index} className="flex items-center space-x-2">
                        <Check className="w-4 h-4 text-green-500" />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* CTA Button */}
                <a 
                  href={plan.id === 'starter' ? 'https://buy.stripe.com/6oU7sL1Mt0B4bXf4A9fMA0u' : plan.id === 'professional' ? 'https://buy.stripe.com/aFa5kD4YFgA2aTb1nXfMA0v' : 'https://buy.stripe.com/3cI00jcr74Rk7GZeaJfMA0w'}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`w-full py-3 rounded-xl font-semibold transition-all ${
                  plan.recommended
                    ? 'bg-[#3C59B2] text-white hover:bg-[#2A4491]'
                    : 'bg-gray-100 text-gray-700 hover:bg-[#3C59B2] hover:text-white'
                } block text-center`}>
                  Get Started Now
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ROICalculatorPricing;