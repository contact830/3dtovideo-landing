import React from 'react';
import { Video, RotateCw, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-transparent text-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-12 items-start">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <img 
                src="https://www.dropbox.com/scl/fi/oxo5i7y7l8pel7nsq4j9p/Capture-d-cran-2025-09-09-21.02.16.png?rlkey=xnonng3s2yr5spdr0krx85ugy&st=h5e718dy&raw=1" 
                alt="3DtoVideo Logo" 
                className="h-12 w-auto rounded-lg"
              />
            </div>
            <p className="text-gray-600 mb-6 leading-relaxed max-w-sm text-sm">
              Transform your Matterport tours into professional video packages that sell properties faster.
            </p>
            <div className="text-gray-600">
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-gray-500" />
                <a href="mailto:contact@3dtovideo.com" className="hover:text-gray-900 transition-colors text-sm">
                  contact@3dtovideo.com
                </a>
              </div>
            </div>
          </div>

          {/* Services */}
          <div className="lg:col-span-2">
            <h3 className="font-semibold mb-6 text-lg">Our Services</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <ul className="space-y-3">
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors text-sm flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                    <span>Walkthrough Videos</span>
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors text-sm flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                    <span>360° Showcases</span>
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors text-sm flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                    <span>Marketing Slideshows</span>
                  </a>
                </li>
              </ul>
              <ul className="space-y-3">
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors text-sm flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                    <span>Drone Edits</span>
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-600 hover:text-gray-900 transition-colors text-sm flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 bg-gray-400 rounded-full"></span>
                    <span>Property Websites</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-200 my-8"></div>

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-gray-500 text-sm">
            © {new Date().getFullYear()} 3dtovideo.com. All rights reserved.
          </div>
          <div className="flex items-center space-x-6">
            <a href="#pricing" className="text-gray-500 hover:text-gray-900 transition-colors text-sm">
              Pricing
            </a>
            <a href="https://www.youtube.com/@3dtovideo/playlists" target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-gray-900 transition-colors text-sm">
              Portfolio
            </a>
            <a href="#faq" className="text-gray-500 hover:text-gray-900 transition-colors text-sm">
              FAQ
            </a>
          </div>
          </div>
        </div>
    </footer>
  );
};

export default Footer;