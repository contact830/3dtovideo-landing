import React from 'react';
import { Check, X, TrendingUp, Clock, DollarSign, Zap } from 'lucide-react';

const ProblemSolution: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Turn Your Existing Assets Into Video Gold
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            You already have Matterport tours and photos - we convert them into 5 professional videos that sell properties faster
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Your Current Business */}
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-8 border border-blue-200 transform hover:scale-110 transition-transform duration-200">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-900 mb-2">Your Current Business</h3>
            </div>
            
            <div className="space-y-3">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Check className="w-5 h-5 text-green-600" />
                  <span className="text-blue-900">Successful photography</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Check className="w-5 h-5 text-green-600" />
                  <span className="text-blue-900">Matterport expertise</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-blue-900">Inconsistent video offerings</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-blue-900">Missing recurring revenue</span>
                </div>
              </div>
            </div>
          </div>

          {/* The Challenge */}
          <div className="bg-gradient-to-br from-red-50 to-orange-100 rounded-2xl p-8 border border-red-200 transform hover:scale-110 transition-transform duration-200">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-red-900 mb-2">The Challenge</h3>
            </div>
            
            <div className="space-y-3">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-red-900">Video production takes weeks</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-red-900">Hard to price consistently</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-red-900">Can't promise fast delivery</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <X className="w-5 h-5 text-red-500" />
                  <span className="text-red-900">Unpredictable workload</span>
                </div>
              </div>
            </div>
          </div>

          {/* Our Solution */}
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 border border-green-200 relative overflow-hidden transform hover:scale-110 transition-transform duration-200">
            <div className="absolute top-4 right-4 bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
              SOLUTION
            </div>
            
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-green-900 mb-2">Our Solution</h3>
            </div>
            
            <div className="space-y-3">
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Check className="w-5 h-5 text-green-600" />
                  <span className="text-green-900">24h guaranteed delivery</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Check className="w-5 h-5 text-green-600" />
                  <span className="text-green-900">Predictable monthly capacity</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Check className="w-5 h-5 text-green-600" />
                  <span className="text-green-900">Consistent per-property pricing</span>
                </div>
              </div>
              <div className="text-center">
                <div className="flex items-center justify-center space-x-2">
                  <Check className="w-5 h-5 text-green-600" />
                  <span className="text-green-900">Recurring revenue stream</span>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};

export default ProblemSolution;