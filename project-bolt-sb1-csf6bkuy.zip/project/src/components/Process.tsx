import React from 'react';
import { CreditCard, Upload, Coffee, Download } from 'lucide-react';

const steps = [
  {
    id: 1,
    title: 'Subscribe',
    description: 'Choose monthly plan',
    icon: CreditCard,
    color: 'blue'
  },
  {
    id: 2,
    title: 'Upload',
    description: 'Send Matterport URL + photos',
    icon: Upload,
    color: 'green'
  },
  {
    id: 3,
    title: 'Relax',
    description: 'We create 5 videos + dedicated website',
    icon: Coffee,
    color: 'orange'
  },
  {
    id: 4,
    title: 'Deliver',
    description: '24h delivery (Mon-Thu)',
    icon: Download,
    color: 'purple'
  }
];

const Process: React.FC = () => {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Simple Conversion Process
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            From your Matterport tour + photos to 5 professional videos in just 24 hours
          </p>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={step.id} className="text-center">
                {/* Step Icon */}
                <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center bg-gradient-to-br ${
                  step.color === 'blue' ? 'from-blue-500 to-blue-600' :
                  step.color === 'green' ? 'from-green-500 to-green-600' :
                  step.color === 'orange' ? 'from-orange-500 to-orange-600' :
                  'from-purple-500 to-purple-600'
                } shadow-lg transform hover:scale-110 transition-transform duration-200`}>
                  <step.icon className="w-8 h-8 text-white" />
                </div>
                
                {/* Step Number */}
                <div className="w-8 h-8 mx-auto mb-2 bg-white border-2 border-gray-200 rounded-full flex items-center justify-center text-sm font-bold text-gray-600 shadow-sm">
                  {step.id}
                </div>
                
                {/* Step Content */}
                <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Process;