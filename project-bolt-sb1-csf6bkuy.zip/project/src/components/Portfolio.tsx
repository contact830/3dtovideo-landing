import React, { useState } from 'react';
import { Play, ExternalLink, Eye, Clock, Calendar } from 'lucide-react';

// Sample video data - replace with your actual YouTube videos
const portfolioVideos = [
  {
    id: 'syeVR2aA4mU',
    title: 'Industry Expert Interview - Adding Video Services to Photo Packages',
    description: 'Learn how real estate professionals are successfully adding video conversion services to their existing photo packages.',
    category: 'Interview',
    duration: '5:23',
    views: '2.1K',
    publishedAt: '2024-01-15'
  },
  {
    id: 'dQw4w9WgXcQ', // Replace with actual video IDs
    title: 'Luxury Home Walkthrough - Before & After Conversion',
    description: 'See how we transformed a Matterport tour and photos into 5 professional marketing videos.',
    category: 'Walkthrough',
    duration: '3:45',
    views: '5.2K',
    publishedAt: '2024-01-10'
  },
  {
    id: 'dQw4w9WgXcQ', // Replace with actual video IDs
    title: '360° Showcase Template Examples',
    description: 'Explore different template options for 360° showcases and interactive experiences.',
    category: '360° Showcase',
    duration: '4:12',
    views: '3.8K',
    publishedAt: '2024-01-08'
  },
  {
    id: 'dQw4w9WgXcQ', // Replace with actual video IDs
    title: 'Premium Marketing Slideshow Samples',
    description: 'Professional slideshow examples showing different styles and transitions.',
    category: 'Slideshow',
    duration: '2:30',
    views: '4.5K',
    publishedAt: '2024-01-05'
  },
];

const categories = ['All', 'Interview', 'Walkthrough', '360° Showcase', 'Slideshow'];

const Portfolio: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedVideo, setSelectedVideo] = useState<string | null>(null);

  const filteredVideos = selectedCategory === 'All' 
    ? portfolioVideos 
    : portfolioVideos.filter(video => video.category === selectedCategory);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <section id="portfolio" className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Portfolio & Examples
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See real examples of Matterport tours and photos converted into professional marketing videos
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12 mt-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Featured Video Player */}
        {selectedVideo && (
          <div className="mb-12">
            <div className="max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-1">
                <div className="bg-gray-900 rounded-xl overflow-hidden">
                  <iframe
                    className="w-full aspect-video"
                    src={`https://www.youtube.com/embed/${selectedVideo}`}
                    title="Selected Portfolio Video"
                    frameBorder="0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
              <div className="text-center mt-4">
                <button
                  onClick={() => setSelectedVideo(null)}
                  className="text-blue-600 hover:text-blue-700 font-medium"
                >
                  Close Video
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Video Grid */}
        <div className="max-w-md mx-auto">
          {filteredVideos.slice(0, 1).map((video) => (
            <div
              key={video.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
              onClick={() => setSelectedVideo(video.id)}
            >
              {/* Video Thumbnail */}
              <div className="relative aspect-video bg-gray-900">
                <img
                  src={`https://img.youtube.com/vi/${video.id}/maxresdefault.jpg`}
                  alt={video.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                    <Play className="w-8 h-8 text-white ml-1" />
                  </div>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/80 text-white px-2 py-1 rounded text-sm">
                  {video.duration}
                </div>
              </div>

              {/* Video Info */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    {video.category}
                  </span>
                  <div className="flex items-center space-x-1 text-gray-500 text-sm">
                    <Eye className="w-4 h-4" />
                    <span>{video.views}</span>
                  </div>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-2">
                  {video.title}
                </h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                  {video.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Portfolio;